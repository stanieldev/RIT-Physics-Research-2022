X0=load('Phase0ourX0.txt');
Y0=load('Phase0ourY0.txt');
Z0=load('Phase0ourZ0.txt');
X100=load('Phase0ourX100.txt');
Y100=load('Phase0ourY100.txt');
Z100=load('Phase0ourZ100.txt');
X200=load('Phase0ourX200.txt');
Y200=load('Phase0ourY200.txt');
Z200=load('Phase0ourZ200.txt');
X300=load('Phase0ourX300.txt');
Y300=load('Phase0ourY300.txt');
Z300=load('Phase0ourZ300.txt');
X400=load('Phase0ourX400.txt');
Y400=load('Phase0ourY400.txt');
Z400=load('Phase0ourZ400.txt');
X500=load('Phase0ourX500.txt');
Y500=load('Phase0ourY500.txt');
Z500=load('Phase0ourZ500.txt');
X600=load('Phase0ourX600.txt');
Y600=load('Phase0ourY600.txt');
Z600=load('Phase0ourZ600.txt');
X700=load('Phase0ourX700.txt');
Y700=load('Phase0ourY700.txt');
Z700=load('Phase0ourZ700.txt');
X800=load('Phase0ourX800.txt');
Y800=load('Phase0ourY800.txt');
Z800=load('Phase0ourZ800.txt');
X900=load('Phase0ourX900.txt');
Y900=load('Phase0ourY900.txt');
Z900=load('Phase0ourZ900.txt');
X1000=load('Phase0ourX1000.txt');
Y1000=load('Phase0ourY1000.txt');
Z1000=load('Phase0ourZ1000.txt');
X1100=load('Phase0ourX1100.txt');
Y1100=load('Phase0ourY1100.txt');
Z1100=load('Phase0ourZ1100.txt');
% figure('Name', '0');
% surf(X0, Y0, Z0);
% figure('Name', '100');
% surf(X100, Y100, Z100);
% figure('Name', '200');
% surf(X200, Y200, Z200);
% figure('Name', '300');
% surf(X300, Y300, Z300);
% figure('Name', '400');
% surf(X400, Y400, Z400);
% figure('Name', '500');
% surf(X500, Y500, Z500);
% figure('Name', '600');
% surf(X600, Y600, Z600);
% figure('Name', '700');
% surf(X700, Y700, Z700);
% figure('Name', '800');
% surf(X800, Y800, Z800);
% figure('Name', '900');
% surf(X900, Y900, Z900);
% figure('Name', '1000');
% surf(X1000,Y1000,Z1000);
% figure('Name', '1100');
% surf(X1100,Y1100,Z1100);
hold all;
X = [];
Y = [];
X = [X X1100(1,:) X1100(:,1)' X1100(end,:) X1100(:,end)'];
Y = [Y Y1100(1,:) Y1100(:,1)' Y1100(end,:) Y1100(:,end)'];
[x0 y0 R] = circle_fit(X,Y)
x = linspace(x0-R,x0+R,101);
y = sqrt((R).^2 - (x - x0).^2) + (y0);
negy = -sqrt((R).^2 - (x - x0).^2) + (y0);
plot(x,y,'k')
plot(x,negy,'k')
theta = zeros(17,17);
plot(X1100,Y1100)

% adj = sqrt( (X1100(2,2)-X1100(1,1))^2 + (Y1100(2,2)-Y1100(1,1))^2);
% opp = Z1100(2,2) - Z1100(1,1);
% theta(1,1) = atan(opp/adj)
% adj = sqrt( (X1100(2,16)-X1100(1,17))^2 + (Y1100(2,16)-Y1100(1,17))^2);
% opp = Z1100(2,16) - Z1100(1,17);
% theta(1,17) = atan(opp/adj)
% adj = sqrt( (X1100(16,2)-X1100(17,1))^2 + (Y1100(16,2)-Y1100(17,1))^2);
% opp = Z1100(16,2) - Z1100(17,1);
% theta(17,1) = atan(opp/adj)
% adj = sqrt( (X1100(16,16)-X1100(17,17))^2 + (Y1100(16,16)-Y1100(17,17))^2);
% opp = Z1100(16,16) - Z1100(17,17);
% theta(17,17) = atan(opp/adj)
% for i=2:16
%     adj = sqrt( (X1100(2,i)-X1100(1,i))^2 + (Y1100(2,i)-Y1100(1,i))^2);
% 	opp = Z1100(2,i) - Z1100(1,i);
%     theta(1,i) = atan(opp/adj);
%     adj = sqrt( (X1100(i,2)-X1100(i,1))^2 + (Y1100(i,2)-Y1100(i,1))^2);
% 	opp = Z1100(i,2) - Z1100(i,1);
%     theta(i,1) = atan(opp/adj);
%     adj = sqrt( (X1100(16,i)-X1100(17,i))^2 + (Y1100(16,i)-Y1100(17,i))^2);
% 	opp = Z1100(16,i) - Z1100(17,i);
%     theta(17,i) = atan(opp/adj);
%     adj = sqrt( (X1100(i,16)-X1100(i,17))^2 + (Y1100(i,16)-Y1100(i,17))^2);
% 	opp = Z1100(i,16) - Z1100(i,17);
%     theta(i,17) = atan(opp/adj);
% end
% theta