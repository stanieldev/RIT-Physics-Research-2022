X1100norm=load('Part1X1100.txt');
Y1100norm=load('Part1Y1100.txt');
X11000=load("0alphaX1100.txt");
Y11000=load("0alphaY1100.txt");
Z11000=load("0alphaZ1100.txt");
X110025=load("25alphaX1100.txt");
Y110025=load("25alphaY1100.txt");
X110075=load("75alphaX1100.txt");
Y110075=load("75alphaY1100.txt");
X11001=load("1alphaX1100.txt");
Y11001=load("1alphaY1100.txt");
Z11001=load("1alphaZ1100.txt");
hold all;
plot(X1100norm(1,:), Y1100norm(1,:), 'k')
plot(X1100norm(17, :), Y1100norm(17,:), 'k')
plot(X1100norm(:,1), Y1100norm(:,1), 'k')
plot(X1100norm(:,17), Y1100norm(:,17), 'k')
plot(X11000(1,:), Y11000(1,:), 'b')
plot(X11000(17, :), Y11000(17,:), 'b')
plot(X11000(:,1), Y11000(:,1), 'b')
plot(X11000(:,17), Y11000(:,17), 'b')
plot(X110025(1,:), Y110025(1,:), 'r')
plot(X110025(17, :), Y110025(17,:), 'r')
plot(X110025(:,1), Y110025(:,1), 'r')
plot(X110025(:,17), Y110025(:,17), 'r')
plot(X110075(1,:), Y110075(1,:), 'g')
plot(X110075(17, :), Y110075(17,:), 'g')
plot(X110075(:,1), Y110075(:,1), 'g')
plot(X110075(:,17), Y110075(:,17), 'g')
plot(X11001(1,:), Y11001(1,:), 'c')
plot(X11001(17, :), Y11001(17,:), 'c')
plot(X11001(:,1), Y11001(:,1), 'c')
plot(X11001(:,17), Y11001(:,17), 'c')

%% Circle Fit
x = [X1100norm(1,:) X1100norm(:,1)' X1100norm(end,:) X1100norm(:,end)'];
y = [Y1100norm(1,:) Y1100norm(:,1)' Y1100norm(end,:) Y1100norm(:,end)'];
x=x(:);
y=y(:);
A = [-2*x -2*y ones(length(x),1)];
xnew = A\-(x.^2+y.^2);
xo=xnew(1);
yo=xnew(2);
R = sqrt(  xo.^2 + yo.^2  - xnew(3));
% error
numbers = size(x);
errornorm = 0;
for i = 1 : numbers(1)*numbers(2)
    errornorm = errornorm + abs((sqrt((x(i)-xnew(1))^2 + (y(i)-xnew(2))^2) - R));
end
x = [X110025(1,:) X110025(:,1)' X110025(end,:) X110025(:,end)'];
y = [Y110025(1,:) Y110025(:,1)' Y110025(end,:) Y110025(:,end)'];
x=x(:);
y=y(:);
A = [-2*x -2*y ones(length(x),1)];
xnew = A\-(x.^2+y.^2);
xo=xnew(1);
yo=xnew(2);
R = sqrt(  xo.^2 + yo.^2  - xnew(3));
% error
numbers = size(x);
error25 = 0;
for i = 1 : numbers(1)*numbers(2)
    error25 = error25 + abs((sqrt((x(i)-xnew(1))^2 + (y(i)-xnew(2))^2) - R));
end
x = [X110075(1,:) X110075(:,1)' X110075(end,:) X110075(:,end)'];
y = [Y110075(1,:) Y110075(:,1)' Y110075(end,:) Y110075(:,end)'];x=x(:);
y=y(:);
A = [-2*x -2*y ones(length(x),1)];
xnew = A\-(x.^2+y.^2);
xo=xnew(1);
yo=xnew(2);
R = sqrt(  xo.^2 + yo.^2  - xnew(3));
% error
numbers = size(x);
error75 = 0;
for i = 1 : numbers(1)*numbers(2)
    error75 = error75 + abs((sqrt((x(i)-xnew(1))^2 + (y(i)-xnew(2))^2) - R));
end
errornorm
error25
error75