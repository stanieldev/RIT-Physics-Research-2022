X0=load('Part 2X0.txt');
Y0=load('Part 2Y0.txt');
Z0=load('Part 2Z0.txt');
X100=load('Part 2X100.txt');
Y100=load('Part 2Y100.txt');
Z100=load('Part 2Z100.txt');
X200=load('Part 2X200.txt');
Y200=load('Part 2Y200.txt');
Z200=load('Part 2Z200.txt');
X300=load('Part 2X300.txt');
Y300=load('Part 2Y300.txt');
Z300=load('Part 2Z300.txt');
X400=load('Part 2X400.txt');
Y400=load('Part 2Y400.txt');
Z400=load('Part 2Z400.txt');
X500=load('Part 2X500.txt');
Y500=load('Part 2Y500.txt');
Z500=load('Part 2Z500.txt');
X600=load('Part 2X600.txt');
Y600=load('Part 2Y600.txt');
Z600=load('Part 2Z600.txt');
X700=load('Part 2X700.txt');
Y700=load('Part 2Y700.txt');
Z700=load('Part 2Z700.txt');
X800=load('Part 2X800.txt');
Y800=load('Part 2Y800.txt');
Z800=load('Part 2Z800.txt');
X900=load('Part 2X900.txt');
Y900=load('Part 2Y900.txt');
Z900=load('Part 2Z900.txt');
X1000=load('Part 2X1000.txt');
Y1000=load('Part 2Y1000.txt');
Z1000=load('Part 2Z1000.txt');
X1100=load('Part 2X1100.txt');
Y1100=load('Part 2Y1100.txt');
Z1100=load('Part 2Z1100.txt');
% figure('Name', '0');
% surf(X0, Y0, Z0);
% figure('Name', '100');
% surf(X100, Y100, Z100);
% figure('Name', '200');
% surf(X200, Y200, Z200);
% figure('Name', '300');
% surf(X300, Y300, Z300);
% figure('Name', '400');
% surf(X400, Y400, Z400);
% figure('Name', '500');
% surf(X500, Y500, Z500);
% figure('Name', '600');
% surf(X600, Y600, Z600);
% figure('Name', '700');
% surf(X700, Y700, Z700);
% figure('Name', '800');
% surf(X800, Y800, Z800);
% figure('Name', '900');
% surf(X900, Y900, Z900);
% figure('Name', '1000');
% surf(X1000,Y1000,Z1000);
% figure('Name', '1100');
mesh(X1100,Y1100,Z1100);
% hold all;
% figure;
% X = [];
% Y = [];
% X = [X X1100(1,:) X1100(:,1)' X1100(end,:) X1100(:,end)'];
% Y = [Y Y1100(1,:) Y1100(:,1)' Y1100(end,:) Y1100(:,end)'];
% [x0 y0 R] = circle_fit(X,Y)
% x = linspace(x0-R,x0+R,101);
% y = sqrt((R).^2 - (x - x0).^2) + (y0);
% negy = -sqrt((R).^2 - (x - x0).^2) + (y0);
% plot(x,y)
hold on
% plot(x,negy)
% plot(X0(1,:), Y0(1,:), '--b')
% plot(X0(17, :), Y0(17,:), '--b')
% plot(X0(:,1), Y0(:,1), '--b')
% plot(X0(:,17), Y0(:,17), '-b')
% plot(X100(1,:), Y100(1,:), '--c')
% plot(X100(17, :), Y100(17,:), '--c')
% plot(X100(:,1), Y100(:,1), '--c')
% plot(X100(:,17), Y100(:,17), '-c')
% plot(X200(1,:), Y200(1,:), '--g')
% plot(X200(17, :), Y200(17,:), '--g')
% plot(X200(:,1), Y200(:,1), '--g')
% plot(X200(:,17), Y200(:,17), '-g')
% plot(X1100(1,:), Y1100(1,:), '--k')
% plot(X1100(17, :), Y1100(17,:), '--k')
% plot(X1100(:,1), Y1100(:,1), '--k')
% plot(X1100(:,17), Y1100(:,17), '--k')
% yline(.5*10^(-3),'m')
% yline(-0.5*10^(-3),'m')
% theta = zeros(17,17);
% 
% adj = sqrt( (X1100(2,2)-X1100(1,1))^2 + (Y1100(2,2)-Y1100(1,1))^2);
% opp = Z1100(2,2) - Z1100(1,1);
% theta(1,1) = atan(opp/adj)
% adj = sqrt( (X1100(2,16)-X1100(1,17))^2 + (Y1100(2,16)-Y1100(1,17))^2);
% opp = Z1100(2,16) - Z1100(1,17);
% theta(1,17) = atan(opp/adj)
% adj = sqrt( (X1100(16,2)-X1100(17,1))^2 + (Y1100(16,2)-Y1100(17,1))^2);
% opp = Z1100(16,2) - Z1100(17,1);
% theta(17,1) = atan(opp/adj)
% adj = sqrt( (X1100(16,16)-X1100(17,17))^2 + (Y1100(16,16)-Y1100(17,17))^2);
% opp = Z1100(16,16) - Z1100(17,17);
% theta(17,17) = atan(opp/adj)
% for i=2:16
%     adj = sqrt( (X1100(2,i)-X1100(1,i))^2 + (Y1100(2,i)-Y1100(1,i))^2);
% 	opp = Z1100(2,i) - Z1100(1,i);
%     theta(1,i) = atan(opp/adj);
%     adj = sqrt( (X1100(i,2)-X1100(i,1))^2 + (Y1100(i,2)-Y1100(i,1))^2);
% 	opp = Z1100(i,2) - Z1100(i,1);
%     theta(i,1) = atan(opp/adj);
%     adj = sqrt( (X1100(16,i)-X1100(17,i))^2 + (Y1100(16,i)-Y1100(17,i))^2);
% 	opp = Z1100(16,i) - Z1100(17,i);
%     theta(17,i) = atan(opp/adj);
%     adj = sqrt( (X1100(i,16)-X1100(i,17))^2 + (Y1100(i,16)-Y1100(i,17))^2);
% 	opp = Z1100(i,16) - Z1100(i,17);
%     theta(i,17) = atan(opp/adj);
% end
% theta;