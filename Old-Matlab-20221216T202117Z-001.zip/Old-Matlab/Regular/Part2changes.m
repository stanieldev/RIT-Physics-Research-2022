% X1100=load('Part2X1100.txt');
% Y1100=load('Part2Y1100.txt');
% % Z1100=load('Part2Z1100.txt');
% X110025=load('25alphaX1100.txt')
% Y110025=load('25alphaY1100.txt')
% % Z110025=load('25alphaZ1100.txt')
% X110075=load('75alphaX1100.txt')
% Y110075=load('75alphaY1100.txt')
% % Z110075=load('75alphaZ1100.txt')
% hold all;
% %figure('Name', 'alpha changes, normal angle')
% plot(X1100(1,:), Y1100(1,:), '--b')
% plot(X1100(17, :), Y1100(17,:), '--b')
% plot(X1100(:,1), Y1100(:,1), '--b')
% plot(X1100(:,17), Y1100(:,17), '-b')
% plot(X110025(1,:), Y110025(1,:), '--c')
% plot(X110025(17, :), Y110025(17,:), '--c')
% plot(X110025(:,1), Y110025(:,1), '--c')
% plot(X110025(:,17), Y110025(:,17), '-c')
% plot(X110075(1,:), Y110075(1,:), '--k')
% plot(X110075(17, :), Y110075(17,:), '--k')
% plot(X110075(:,1), Y110075(:,1), '--k')
% plot(X110075(:,17), Y110075(:,17), '--k')
% yline(.5*10^(-3),'m')
% yline(-0.5*10^(-3),'m')
%%%
% X110010deg=load('10degX1100.txt');
% Y110010deg=load('10degY1100.txt');
% % Z110010deg=load('10degZ1100.txt');
% X110010deg25a=load('10deg25aX1100.txt')
% Y110010deg25a=load('10deg25aY1100.txt')
% % Z110010deg25a=load('10deg25aZ1100.txt')
% X110010deg75a=load('10deg75aX1100.txt')
% Y110010deg75a=load('10deg75aY1100.txt')
% Z110010deg75a=load('10deg75aZ1100.txt')
% figure('Name', 'alpha changes, 10 angle')
% hold all;
% plot(X110010deg(1,:), Y110010deg(1,:), '--b')
% plot(X110010deg(17, :), Y110010deg(17,:), '--b')
% plot(X110010deg(:,1), Y110010deg(:,1), '--b')
% plot(X110010deg(:,17), Y110010deg(:,17), '-b')
% plot(X110010deg25a(1,:), Y110010deg25a(1,:), '--c')
% plot(X110010deg25a(17, :), Y110010deg25a(17,:), '--c')
% plot(X110010deg25a(:,1), Y110010deg25a(:,1), '--c')
% plot(X110010deg25a(:,17), Y110010deg25a(:,17), '-c')
% plot(X110010deg75a(1,:), Y110010deg75a(1,:), '--k')
% plot(X110010deg75a(17, :), Y110010deg75a(17,:), '--k')
% plot(X110010deg75a(:,1), Y110010deg75a(:,1), '--k')
% plot(X110010deg75a(:,17), Y110010deg75a(:,17), '--k')
%%%
% figure('Name', 'Part 2 further')
% hold all;
% furtherX2100=load('furtherpart2X2100.txt');
% furtherY2100=load('furtherpart2Y2100.txt');
% % furtherZ1100=load('furtherpart2Z2100');
% plot(furtherX2100(1,:), furtherY2100(1,:), '--b')
% plot(furtherX2100(17, :), furtherY2100(17,:), '--b')
% plot(furtherX2100(:,1), furtherY2100(:,1), '--b')
% plot(furtherX2100(:,17), furtherY2100(:,17), '--b')
%%%
% hold all;
% X0=load('10degsmalltimeX0.txt');
% Y0=load('10degsmalltimeY0.txt');
% X2=load('10degsmalltimeX2.txt');
% Y2=load('10degsmalltimeY2.txt');
% X4=load('10degsmalltimeX4.txt');
% Y4=load('10degsmalltimeY4.txt');
% X6=load('10degsmalltimeX6.txt');
% Y6=load('10degsmalltimeY6.txt');
% X8=load('10degsmalltimeX8.txt');
% Y8=load('10degsmalltimeY8.txt');
% X10=load('10degsmalltimeX10.txt');
% Y10=load('10degsmalltimeY10.txt');
% X25=load('10degsmalltimeX25.txt');
% Y25=load('10degsmalltimeY25.txt');
% X50=load('10degsmalltimeX50.txt');
% Y50=load('10degsmalltimeY50.txt');
% X75=load('10degsmalltimeX75.txt');
% Y75=load('10degsmalltimeY75.txt');
% X100=load('10degsmalltimeX100.txt');
% Y100=load('10degsmalltimeY100.txt');
% plot(X0(1,:), Y0(1,:), '--b')
% plot(X0(17,:), Y0(17,:), '--b')
% plot(X0(:,1), Y0(:,1), '--b')
% plot(X0(:,17), Y0(:,17), '--b')
% plot(X2(1,:), Y2(1,:), '--c')
% plot(X2(17,:), Y2(17,:), '--c')
% plot(X2(:,1), Y2(:,1), '--c')
% plot(X2(:,17), Y2(:,17), '--c')
% plot(X4(1,:), Y4(1,:), '--k')
% plot(X4(17,:), Y4(17,:), '--k')
% plot(X4(:,1), Y4(:,1), '--k')
% plot(X4(:,17), Y4(:,17), '--k')
% plot(X6(1,:), Y6(1,:), '--g')
% plot(X6(17,:), Y6(17,:), '--g')
% plot(X6(:,1), Y6(:,1), '--g')
% plot(X6(:,17), Y6(:,17), '--g')
% plot(X8(1,:), Y8(1,:), '--r')
% plot(X8(17,:), Y8(17,:), '--r')
% plot(X8(:,1), Y8(:,1), '--r')
% plot(X8(:,17), Y8(:,17), '--r')
% plot(X10(1,:), Y10(1,:), '--m')
% plot(X10(17,:), Y10(17,:), '--m')
% plot(X10(:,1), Y10(:,1), '--m')
% plot(X10(:,17), Y10(:,17), '--m')
% plot(X25(1,:), Y25(1,:), '--c')
% plot(X25(17,:), Y25(17,:), '--c')
% plot(X25(:,1), Y25(:,1), '--c')
% plot(X25(:,17), Y25(:,17), '--c')
% plot(X50(1,:), Y50(1,:), '--m')
% plot(X50(17,:), Y50(17,:), '--m')
% plot(X50(:,1), Y50(:,1), '--m')
% plot(X50(:,17), Y50(:,17), '--m')
% plot(X75(1,:), Y75(1,:), '--g')
% plot(X75(17,:), Y75(17,:), '--g')
% plot(X75(:,1), Y75(:,1), '--g')
% plot(X75(:,17), Y75(:,17), '--g')
% plot(X100(1,:), Y100(1,:), '--k')
% plot(X100(17,:), Y100(17,:), '--k')
% plot(X100(:,1), Y100(:,1), '--k')
% plot(X100(:,17), Y100(:,17), '--k')
%%%
% hold all;
% X0=load('10degsmalltimeX0.txt');
% Y0=load('10degsmalltimeY0.txt');
% X2=load('10degsmalltimeX2.txt');
% Y2=load('10degsmalltimeY2.txt');
% X4=load('10degsmalltimeX4.txt');
% Y4=load('10degsmalltimeY4.txt');
% X6=load('10degsmalltimeX6.txt');
% Y6=load('10degsmalltimeY6.txt');
% X8=load('10degsmalltimeX8.txt');
% Y8=load('10degsmalltimeY8.txt');
% X10=load('10degsmalltimeX10.txt');
% Y10=load('10degsmalltimeY10.txt');
% X25=load('10degsmalltimeX25.txt');
% Y25=load('10degsmalltimeY25.txt');
% X50=load('10degsmalltimeX50.txt');
% Y50=load('10degsmalltimeY50.txt');
% X75=load('10degsmalltimeX75.txt');
% Y75=load('10degsmalltimeY75.txt');
% X100=load('10degsmalltimeX100.txt');
% Y100=load('10degsmalltimeY100.txt');
% plot(X0(1,:), Y0(1,:), '--b')
% plot(X0(17,:), Y0(17,:), '--b')
% plot(X0(:,1), Y0(:,1), '--b')
% plot(X0(:,17), Y0(:,17), '--b')
% plot(X2(1,:), Y2(1,:), '--c')
% plot(X2(17,:), Y2(17,:), '--c')
% plot(X2(:,1), Y2(:,1), '--c')
% plot(X2(:,17), Y2(:,17), '--c')
% plot(X4(1,:), Y4(1,:), '--k')
% plot(X4(17,:), Y4(17,:), '--k')
% plot(X4(:,1), Y4(:,1), '--k')
% plot(X4(:,17), Y4(:,17), '--k')
% plot(X6(1,:), Y6(1,:), '--g')
% plot(X6(17,:), Y6(17,:), '--g')
% plot(X6(:,1), Y6(:,1), '--g')
% plot(X6(:,17), Y6(:,17), '--g')
% plot(X8(1,:), Y8(1,:), '--r')
% plot(X8(17,:), Y8(17,:), '--r')
% plot(X8(:,1), Y8(:,1), '--r')
% plot(X8(:,17), Y8(:,17), '--r')
% plot(X10(1,:), Y10(1,:), '--m')
% plot(X10(17,:), Y10(17,:), '--m')
% plot(X10(:,1), Y10(:,1), '--m')
% plot(X10(:,17), Y10(:,17), '--m')
% plot(X25(1,:), Y25(1,:), '--c')
% plot(X25(17,:), Y25(17,:), '--c')
% plot(X25(:,1), Y25(:,1), '--c')
% plot(X25(:,17), Y25(:,17), '--c')
% plot(X50(1,:), Y50(1,:), '--m')
% plot(X50(17,:), Y50(17,:), '--m')
% plot(X50(:,1), Y50(:,1), '--m')
% plot(X50(:,17), Y50(:,17), '--m')
% plot(X75(1,:), Y75(1,:), '--g')
% plot(X75(17,:), Y75(17,:), '--g')
% plot(X75(:,1), Y75(:,1), '--g')
% plot(X75(:,17), Y75(:,17), '--g')
% plot(X100(1,:), Y100(1,:), '--k')
% plot(X100(17,:), Y100(17,:), '--k')
% plot(X100(:,1), Y100(:,1), '--k')
% plot(X100(:,17), Y100(:,17), '--k')
%%%
% hold all;
% X0=load('normsmalltimecorrectedvolX0.txt');
% Y0=load('normsmalltimecorrectedvolY0.txt');
% X2=load('normsmalltimecorrectedvolX2.txt');
% Y2=load('normsmalltimecorrectedvolY2.txt');
% X4=load('normsmalltimecorrectedvolX4.txt');
% Y4=load('normsmalltimecorrectedvolY4.txt');
% X6=load('normsmalltimecorrectedvolX6.txt');
% Y6=load('normsmalltimecorrectedvolY6.txt');
% X8=load('normsmalltimecorrectedvolX8.txt');
% Y8=load('normsmalltimecorrectedvolY8.txt');
% X10=load('normsmalltimecorrectedvolX10.txt');
% Y10=load('normsmalltimecorrectedvolY10.txt');
% X25=load('normsmalltimecorrectedvolX25.txt');
% Y25=load('normsmalltimecorrectedvolY25.txt');
% X50=load('normsmalltimecorrectedvolX50.txt');
% Y50=load('normsmalltimecorrectedvolY50.txt');
% X75=load('normsmalltimecorrectedvolX75.txt');
% Y75=load('normsmalltimecorrectedvolY75.txt');
% X100=load('normsmalltimecorrectedvolX100.txt');
% Y100=load('normsmalltimecorrectedvolY100.txt');
% plot(X0(1,:), Y0(1,:), '--b')
% plot(X0(17,:), Y0(17,:), '--b')
% plot(X0(:,1), Y0(:,1), '--b')
% plot(X0(:,17), Y0(:,17), '--b')
% plot(X2(1,:), Y2(1,:), '--c')
% plot(X2(17,:), Y2(17,:), '--c')
% plot(X2(:,1), Y2(:,1), '--c')
% plot(X2(:,17), Y2(:,17), '--c')
% plot(X4(1,:), Y4(1,:), '--k')
% plot(X4(17,:), Y4(17,:), '--k')
% plot(X4(:,1), Y4(:,1), '--k')
% plot(X4(:,17), Y4(:,17), '--k')
% plot(X6(1,:), Y6(1,:), '--r')
% plot(X6(17,:), Y6(17,:), '--r')
% plot(X6(:,1), Y6(:,1), '--r')
% plot(X6(:,17), Y6(:,17), '--r')
% plot(X8(1,:), Y8(1,:), '--g')
% plot(X8(17,:), Y8(17,:), '--g')
% plot(X8(:,1), Y8(:,1), '--g')
% plot(X8(:,17), Y8(:,17), '--g')
% plot(X10(1,:), Y10(1,:), '--m')
% plot(X10(17,:), Y10(17,:), '--m')
% plot(X10(:,1), Y10(:,1), '--m')
% plot(X10(:,17), Y10(:,17), '--m')
% % plot(X25(1,:), Y25(1,:), '--c')
% % plot(X25(17,:), Y25(17,:), '--c')
% % plot(X25(:,1), Y25(:,1), '--c')
% % plot(X25(:,17), Y25(:,17), '--c')
% % plot(X50(1,:), Y50(1,:), '--m')
% % plot(X50(17,:), Y50(17,:), '--m')
% % plot(X50(:,1), Y50(:,1), '--m')
% % plot(X50(:,17), Y50(:,17), '--m')
% % plot(X75(1,:), Y75(1,:), '--g')
% % plot(X75(17,:), Y75(17,:), '--g')
% % plot(X75(:,1), Y75(:,1), '--g')
% % plot(X75(:,17), Y75(:,17), '--g')
% % plot(X100(1,:), Y100(1,:), '--k')
% % plot(X100(17,:), Y100(17,:), '--k')
% % plot(X100(:,1), Y100(:,1), '--k')
% % plot(X100(:,17), Y100(:,17), '--k')
% yline(.5*10^(-3),'b')
% yline(-0.5*10^(-3),'b')
%%%
% hold all;
% X0=load('normsmalltimecorrectedvolX0.txt');
% Y0=load('normsmalltimecorrectedvolY0.txt');
% X2=load('normsmalltimecorrectedvolX2.txt');
% Y2=load('normsmalltimecorrectedvolY2.txt');
% X4=load('normsmalltimecorrectedvolX4.txt');
% Y4=load('normsmalltimecorrectedvolY4.txt');
% X6=load('normsmalltimecorrectedvolX6.txt');
% Y6=load('normsmalltimecorrectedvolY6.txt');
% X8=load('normsmalltimecorrectedvolX8.txt');
% Y8=load('normsmalltimecorrectedvolY8.txt');
% X10=load('normsmalltimecorrectedvolX10.txt');
% Y10=load('normsmalltimecorrectedvolY10.txt');
% X25=load('normsmalltimecorrectedvolX25.txt');
% Y25=load('normsmalltimecorrectedvolY25.txt');
% X50=load('normsmalltimecorrectedvolX50.txt');
% Y50=load('normsmalltimecorrectedvolY50.txt');
% X75=load('normsmalltimecorrectedvolX75.txt');
% Y75=load('normsmalltimecorrectedvolY75.txt');
% X100=load('normsmalltimecorrectedvolX100.txt');
% Y100=load('normsmalltimecorrectedvolY100.txt');
% plot(X0(1,:), Y0(1,:), '--b')
% plot(X0(17,:), Y0(17,:), '--b')
% plot(X0(:,1), Y0(:,1), '--b')
% plot(X0(:,17), Y0(:,17), '--b')
% plot(X2(1,:), Y2(1,:), '--c')
% plot(X2(17,:), Y2(17,:), '--c')
% plot(X2(:,1), Y2(:,1), '--c')
% plot(X2(:,17), Y2(:,17), '--c')
% plot(X4(1,:), Y4(1,:), '--k')
% plot(X4(17,:), Y4(17,:), '--k')
% plot(X4(:,1), Y4(:,1), '--k')
% plot(X4(:,17), Y4(:,17), '--k')
% plot(X6(1,:), Y6(1,:), '--r')
% plot(X6(17,:), Y6(17,:), '--r')
% plot(X6(:,1), Y6(:,1), '--r')
% plot(X6(:,17), Y6(:,17), '--r')
% plot(X8(1,:), Y8(1,:), '--g')
% plot(X8(17,:), Y8(17,:), '--g')
% plot(X8(:,1), Y8(:,1), '--g')
% plot(X8(:,17), Y8(:,17), '--g')
% plot(X10(1,:), Y10(1,:), '--m')
% plot(X10(17,:), Y10(17,:), '--m')
% plot(X10(:,1), Y10(:,1), '--m')
% plot(X10(:,17), Y10(:,17), '--m')
% % plot(X25(1,:), Y25(1,:), '--c')
% % plot(X25(17,:), Y25(17,:), '--c')
% % plot(X25(:,1), Y25(:,1), '--c')
% % plot(X25(:,17), Y25(:,17), '--c')
% % plot(X50(1,:), Y50(1,:), '--m')
% % plot(X50(17,:), Y50(17,:), '--m')
% % plot(X50(:,1), Y50(:,1), '--m')
% % plot(X50(:,17), Y50(:,17), '--m')
% % plot(X75(1,:), Y75(1,:), '--g')
% % plot(X75(17,:), Y75(17,:), '--g')
% % plot(X75(:,1), Y75(:,1), '--g')
% % plot(X75(:,17), Y75(:,17), '--g')
% % plot(X100(1,:), Y100(1,:), '--k')
% % plot(X100(17,:), Y100(17,:), '--k')
% % plot(X100(:,1), Y100(:,1), '--k')
% % plot(X100(:,17), Y100(:,17), '--k')
% yline(.5*10^(-3),'b')
% yline(-0.5*10^(-3),'b')
%%%
% hold all;
% X0=load('multilineX0.txt');
% Y0=load('multilineY0.txt');
% % X2=load('multilineX2.txt');
% % Y2=load('multilineY2.txt');
% % X4=load('multilineX4.txt');
% % Y4=load('multilineY4.txt');
% % X6=load('multilineX6.txt');
% % Y6=load('multilineY6.txt');
% % X8=load('multilineX8.txt');
% % Y8=load('multilineY8.txt');
% % X10=load('multilineX10.txt');
% % Y10=load('multilineY10.txt');
% % X25=load('multilineX25.txt');
% % Y25=load('multilineY25.txt');
% % X50=load('multilineX50.txt');
% % Y50=load('multilineY50.txt');
% % X75=load('multilineX75.txt');
% % Y75=load('multilineY75.txt');
% X100=load('multilineX100.txt');
% Y100=load('multilineY100.txt');
% % X125=load('multilineX125.txt');
% % Y125=load('multilineY125.txt');
% % X150=load('multilineX150.txt');
% % Y150=load('multilineY150.txt');
% % X175=load('multilineX175.txt');
% % Y175=load('multilineY175.txt');
% X1200=load('multilineX1200.txt');
% Y1200=load('multilineY1200.txt');
% X1400=load('multilineX1400.txt');
% Y1400=load('multilineY1400.txt');
% X1600=load('multilineX1600.txt');
% Y1600=load('multilineY1600.txt');
% X1800=load('multilineX1800.txt');
% Y1800=load('multilineY1800.txt');
% Z1800=load('multilineZ1800.txt');
% X2000=load('multilineX2000.txt');
% Y2000=load('multilineY2000.txt');
% Z2000=load('multilineZ2000.txt');
% plot(X0(1,:), Y0(1,:), '--b')
% plot(X0(25,:), Y0(25,:), '--b')
% plot(X0(:,1), Y0(:,1), '--b')
% plot(X0(:,25), Y0(:,25), '--b')
% % plot(X2(1,:), Y2(1,:), '--c')
% % plot(X2(17,:), Y2(17,:), '--c')
% % plot(X2(:,1), Y2(:,1), '--c')
% % plot(X2(:,17), Y2(:,17), '--c')
% % plot(X4(1,:), Y4(1,:), '--k')
% % plot(X4(17,:), Y4(17,:), '--k')
% % plot(X4(:,1), Y4(:,1), '--k')
% % plot(X4(:,17), Y4(:,17), '--k')
% % plot(X6(1,:), Y6(1,:), '--r')
% % plot(X6(17,:), Y6(17,:), '--r')
% % plot(X6(:,1), Y6(:,1), '--r')
% % plot(X6(:,17), Y6(:,17), '--r')
% % plot(X8(1,:), Y8(1,:), '--g')
% % plot(X8(17,:), Y8(17,:), '--g')
% % plot(X8(:,1), Y8(:,1), '--g')
% % plot(X8(:,17), Y8(:,17), '--g')
% % plot(X10(1,:), Y10(1,:), '--m')
% % plot(X10(17,:), Y10(17,:), '--m')
% % plot(X10(:,1), Y10(:,1), '--m')
% % plot(X10(:,17), Y10(:,17), '--m')
% % plot(X25(1,:), Y25(1,:), '--c')
% % plot(X25(17,:), Y25(17,:), '--c')
% % plot(X25(:,1), Y25(:,1), '--c')
% % plot(X25(:,17), Y25(:,17), '--c')
% % plot(X50(1,:), Y50(1,:), '--m')
% % plot(X50(17,:), Y50(17,:), '--m')
% % plot(X50(:,1), Y50(:,1), '--m')
% % plot(X50(:,17), Y50(:,17), '--m')
% % plot(X75(1,:), Y75(1,:), '--g')
% % plot(X75(17,:), Y75(17,:), '--g')
% % plot(X75(:,1), Y75(:,1), '--g')
% % plot(X75(:,17), Y75(:,17), '--g')
% % plot(X100(1,:), Y100(1,:), '--k')
% % plot(X100(17,:), Y100(17,:), '--k')
% % plot(X100(:,1), Y100(:,1), '--k')
% % plot(X100(:,17), Y100(:,17), '--k')
% % plot(X125(1,:), Y125(1,:), '--c')
% % plot(X125(17,:), Y125(17,:), '--c')
% % plot(X125(:,1), Y125(:,1), '--c')
% % plot(X125(:,17), Y125(:,17), '--c')
% % plot(X150(1,:), Y150(1,:), '--m')
% % plot(X150(17,:), Y150(17,:), '--m')
% % plot(X150(:,1), Y150(:,1), '--m')
% % plot(X150(:,17), Y150(:,17), '--m')
% %plot(X175(1,:), Y175(1,:), '--m')
% %plot(X175(17,:), Y175(17,:), '--m')
% %plot(X175(:,1), Y175(:,1), '--m')
% %plot(X175(:,17), Y175(:,17), '--m')
% plot(X1200(1,:), Y1200(1,:), '--k')
% plot(X1200(25,:), Y1200(25,:), '--k')
% plot(X1200(:,1), Y1200(:,1), '--k')
% plot(X1200(:,25), Y1200(:,25), '--k')
% plot(X1400(1,:), Y1400(1,:), '--g')
% plot(X1400(25,:), Y1400(25,:), '--g')
% plot(X1400(:,1), Y1400(:,1), '--g')
% plot(X1400(:,25), Y1400(:,25), '--g')
% plot(X1600(1,:), Y1600(1,:), '--c')
% plot(X1600(25,:), Y1600(25,:), '--c')
% plot(X1600(:,1), Y1600(:,1), '--c')
% plot(X1600(:,25), Y1600(:,25), '--c')
% plot(X1800(1,:), Y1800(1,:), '--b')
% plot(X1800(25,:), Y1800(25,:), '--b')
% plot(X1800(:,1), Y1800(:,1), '--b')
% plot(X1800(:,25), Y1800(:,25), '--b')
% plot(X2000(1,:), Y2000(1,:), '--r')
% plot(X2000(25,:), Y2000(25,:), '--r')
% plot(X2000(:,1), Y2000(:,1), '--r')
% plot(X2000(:,25), Y2000(:,25), '--r')
% yline(.25*10^(-2),'b')
% yline(-0.25*10^(-2),'b')
% yline(.75*10^(-2),'b')
% yline(-0.75*10^(-2),'b')
%%%%%%%%%%%%%%%%%
% hold all
% X0=load('XitwocompletedX0.txt');
% Y0=load('XitwocompletedY0.txt');
% Z0=load('XitwocompletedZ0.txt');
% X10=load('XitwocompletedX100.txt');
% Y10=load('XitwocompletedY100.txt');
% Z10=load('XitwocompletedZ100.txt');
% X20=load('XitwocompletedX200.txt');
% Y20=load('XitwocompletedY200.txt');
% Z20=load('XitwocompletedZ200.txt');
% X30=load('XitwocompletedX300.txt');
% Y30=load('XitwocompletedY300.txt');
% Z30=load('XitwocompletedZ300.txt');
% X40=load('XitwocompletedX400.txt');
% Y40=load('XitwocompletedY400.txt');
% Z40=load('XitwocompletedZ400.txt');
% X50=load('XitwocompletedX500.txt');
% Y50=load('XitwocompletedY500.txt');
% Z50=load('XitwocompletedZ500.txt');
% X60=load('XitwocompletedX600.txt');
% Y60=load('XitwocompletedY600.txt');
% X70=load('XitwocompletedX700.txt');
% Y70=load('XitwocompletedY700.txt');
% X80=load('XitwocompletedX800.txt');
% Y80=load('XitwocompletedY800.txt');
% Xmax=load('XitwocompletedX2100.txt');
% Ymax=load('XitwocompletedY2100.txt');
% Zmax=load('XitwocompletedZ2100.txt');
% plot(X0(1,:),  Y0(1,:),  '--b')
% plot(X0(17,:), Y0(17,:), '--b')
% plot(X0(:,1),  Y0(:,1),  '--b')
% plot(X0(:,17), Y0(:,17), '--b')
% plot(X10(1,:),  Y10(1,:), '--m')
% plot(X10(17,:), Y10(17,:), '--m')
% plot(X10(:,1),  Y10(:,1), '--m')
% plot(X10(:,17), Y10(:,17), '--m')
% plot(X20(1,:),  Y20(1,:),  '--k')
% plot(X20(17,:), Y20(17,:), '--k')
% plot(X20(:,1),  Y20(:,1),  '--k')
% plot(X20(:,17), Y20(:,17), '--k')
% plot(X30(1,:),  Y30(1,:),  '--r')
% plot(X30(17,:), Y30(17,:), '--r')
% plot(X30(:,1),  Y30(:,1),  '--r')
% plot(X30(:,17), Y30(:,17), '--r')
% plot(X40(1,:),  Y40(1,:),  '--y')
% plot(X40(17,:), Y40(17,:), '--y')
% plot(X40(:,1),  Y40(:,1),  '--y')
% plot(X40(:,17), Y40(:,17), '--y')
% plot(Xmax(1,:),  Ymax(1,:),  '--g')
% plot(Xmax(17,:), Ymax(17,:), '--g')
% plot(Xmax(:,1),  Ymax(:,1),  '--g')
% plot(Xmax(:,17), Ymax(:,17), '--g')
% yline(0.25*10^(-3),'k')
% yline(-0.25*10^(-3),'k')
% yline(0.75*10^(-3),'k')
% yline(-0.75*10^(-3),'k')
% yline(1.25*10^(-3),'k')
% yline(-1.25*10^(-3),'k')
% surf(Xmax, Ymax, Zmax)
%%%
% hold all
% 
% X0=load('Xitwocompleted25X0.txt');
% Y0=load('Xitwocompleted25Y0.txt');
% Z0=load('Xitwocompleted25Z0.txt');
% X10=load('Xitwocompleted25X100.txt');
% Y10=load('Xitwocompleted25Y100.txt');
% Z10=load('Xitwocompleted25Z100.txt');
% X20=load('Xitwocompleted25X200.txt');
% Y20=load('Xitwocompleted25Y200.txt');
% Z20=load('Xitwocompleted25Z200.txt');
% X30=load('Xitwocompleted25X300.txt');
% Y30=load('Xitwocompleted25Y300.txt');
% Z30=load('Xitwocompleted25Z300.txt');
% X40=load('Xitwocompleted25X400.txt');
% Y40=load('Xitwocompleted25Y400.txt');
% Z40=load('Xitwocompleted25Z400.txt');
% X50=load('Xitwocompleted25X500.txt');
% Y50=load('Xitwocompleted25Y500.txt');
% Z50=load('Xitwocompleted25Z500.txt');
% X60=load('Xitwocompleted25X600.txt');
% Y60=load('Xitwocompleted25Y600.txt');
% X70=load('Xitwocompleted25X700.txt');
% Y70=load('Xitwocompleted25Y700.txt');
% X80=load('Xitwocompleted25X800.txt');
% Y80=load('Xitwocompleted25Y800.txt');
% Xmax=load('Xitwocompleted25X2100.txt');
% Ymax=load('Xitwocompleted25Y2100.txt');
% Zmax=load('Xitwocompleted25Z2100.txt');
% plot(X0(1,:),  Y0(1,:),  '--b')
% plot(X0(25,:), Y0(25,:), '--b')
% plot(X0(:,1),  Y0(:,1),  '--b')
% plot(X0(:,25), Y0(:,25), '--b')
% plot(X10(1,:),  Y10(1,:), '--m')
% plot(X10(25,:), Y10(25,:), '--m')
% plot(X10(:,1),  Y10(:,1), '--m')
% plot(X10(:,25), Y10(:,25), '--m')
% plot(X20(1,:),  Y20(1,:),  '--k')
% plot(X20(25,:), Y20(25,:), '--k')
% plot(X20(:,1),  Y20(:,1),  '--k')
% plot(X20(:,25), Y20(:,25), '--k')
% plot(X30(1,:),  Y30(1,:),  '--r')
% plot(X30(25,:), Y30(25,:), '--r')
% plot(X30(:,1),  Y30(:,1),  '--r')
% plot(X30(:,25), Y30(:,25), '--r')
% plot(X40(1,:),  Y40(1,:),  '--y')
% plot(X40(25,:), Y40(25,:), '--y')
% plot(X40(:,1),  Y40(:,1),  '--y')
% plot(X40(:,25), Y40(:,25), '--y')
% plot(Xmax(1,:),  Ymax(1,:),  '--g')
% plot(Xmax(25,:), Ymax(25,:), '--g')
% plot(Xmax(:,1),  Ymax(:,1),  '--g')
% plot(Xmax(:,25), Ymax(:,25), '--g')
% yline(0.25*10^(-3),'k')
% yline(-0.25*10^(-3),'k')
% yline(0.75*10^(-3),'k')
% yline(-0.75*10^(-3),'k')
% yline(1.25*10^(-3),'k')
% yline(-1.25*10^(-3),'k')
% figure()
% surf(Xmax, Ymax, Zmax)
%%%%%%%%%%%%
% hold all
% X0=load('Xitwocompleted31X0.txt');
% Y0=load('Xitwocompleted31Y0.txt');
% Z0=load('Xitwocompleted31Z0.txt');
% X400=load('Xitwocompleted31X400.txt');
% Y400=load('Xitwocompleted31Y400.txt');
% Z400=load('Xitwocompleted31Z400.txt');
% X800=load('Xitwocompleted31X800.txt');
% Y800=load('Xitwocompleted31Y800.txt');
% Z800=load('Xitwocompleted31Z800.txt');
% X1200=load('Xitwocompleted31X1200.txt');
% Y1200=load('Xitwocompleted31Y1200.txt');
% Z1200=load('Xitwocompleted31Z1200.txt');
% X1600=load('Xitwocompleted31X1600.txt');
% Y1600=load('Xitwocompleted31Y1600.txt');
% Z1600=load('Xitwocompleted31Z1600.txt');
% X2000=load('Xitwocompleted31X2000.txt');
% Y2000=load('Xitwocompleted31Y2000.txt');
% Z2000=load('Xitwocompleted31Z2000.txt');
% plot(X0(1,:),  Y0(1,:),  '--b')
% plot(X0(31,:), Y0(31,:), '--b')
% plot(X0(:,1),  Y0(:,1),  '--b')
% plot(X0(:,31), Y0(:,31), '--b')
% plot(X400(1,:),  Y400(1,:),  '--m')
% plot(X400(31,:), Y400(31,:), '--m')
% plot(X400(:,1),  Y400(:,1),  '--m')
% plot(X400(:,31), Y400(:,31), '--m')
% plot(X800(1,:),  Y800(1,:),  '--k')
% plot(X800(31,:), Y800(31,:), '--k')
% plot(X800(:,1),  Y800(:,1),  '--k')
% plot(X800(:,31), Y800(:,31), '--k')
% plot(X1200(1,:),  Y1200(1,:),  '--r')
% plot(X1200(31,:), Y1200(31,:), '--r')
% plot(X1200(:,1),  Y1200(:,1),  '--r')
% plot(X1200(:,31), Y1200(:,31), '--r')
% plot(X1600(1,:),  Y1600(1,:),  '--g')
% plot(X1600(31,:), Y1600(31,:), '--g')
% plot(X1600(:,1),  Y1600(:,1),  '--g')
% plot(X1600(:,31), Y1600(:,31), '--g')
% plot(X2000(1,:),  Y2000(1,:),  '--c')
% plot(X2000(31,:), Y2000(31,:), '--c')
% plot(X2000(:,1),  Y2000(:,1),  '--c')
% plot(X2000(:,31), Y2000(:,31), '--c')
% yline(0.25*10^(-3),'k')
% yline(-0.25*10^(-3),'k')
% yline(0.75*10^(-3),'k')
% yline(-0.75*10^(-3),'k')
% yline(1.25*10^(-3),'k')
% yline(-1.25*10^(-3),'k')
% figure()
% surf(X2000,Y2000,Z2000)
%%%%%%
% hold all
% X0=load('Xitwocompleted41X0.txt');
% Y0=load('Xitwocompleted41Y0.txt');
% Z0=load('Xitwocompleted41Z0.txt');
% X400=load('Xitwocompleted41X400.txt');
% Y400=load('Xitwocompleted41Y400.txt');
% Z400=load('Xitwocompleted41Z400.txt');
% X800=load('Xitwocompleted41X800.txt');
% Y800=load('Xitwocompleted41Y800.txt');
% Z800=load('Xitwocompleted41Z800.txt');
% X1200=load('Xitwocompleted41X1200.txt');
% Y1200=load('Xitwocompleted41Y1200.txt');
% Z1200=load('Xitwocompleted41Z1200.txt');
% X1600=load('Xitwocompleted41X1600.txt');
% Y1600=load('Xitwocompleted41Y1600.txt');
% Z1600=load('Xitwocompleted41Z1600.txt');
% X2000=load('Xitwocompleted41X2000.txt');
% Y2000=load('Xitwocompleted41Y2000.txt');
% Z2000=load('Xitwocompleted41Z2000.txt');
% plot(X0(1,:),  Y0(1,:),  '--b')
% plot(X0(41,:), Y0(41,:), '--b')
% plot(X0(:,1),  Y0(:,1),  '--b')
% plot(X0(:,41), Y0(:,41), '--b')
% plot(X400(1,:),  Y400(1,:),  '--m')
% plot(X400(41,:), Y400(41,:), '--m')
% plot(X400(:,1),  Y400(:,1),  '--m')
% plot(X400(:,41), Y400(:,41), '--m')
% plot(X800(1,:),  Y800(1,:),  '--k')
% plot(X800(41,:), Y800(41,:), '--k')
% plot(X800(:,1),  Y800(:,1),  '--k')
% plot(X800(:,41), Y800(:,41), '--k')
% plot(X1200(1,:),  Y1200(1,:),  '--r')
% plot(X1200(41,:), Y1200(41,:), '--r')
% plot(X1200(:,1),  Y1200(:,1),  '--r')
% plot(X1200(:,41), Y1200(:,41), '--r')
% plot(X1600(1,:),  Y1600(1,:),  '--g')
% plot(X1600(41,:), Y1600(41,:), '--g')
% plot(X1600(:,1),  Y1600(:,1),  '--g')
% plot(X1600(:,41), Y1600(:,41), '--g')
% plot(X2000(1,:),  Y2000(1,:),  '--c')
% plot(X2000(41,:), Y2000(41,:), '--c')
% plot(X2000(:,1),  Y2000(:,1),  '--c')
% plot(X2000(:,41), Y2000(:,41), '--c')
% yline(0.25*10^(-3),'k')
% yline(-0.25*10^(-3),'k')
% yline(0.75*10^(-3),'k')
% yline(-0.75*10^(-3),'k')
% yline(1.25*10^(-3),'k')
% yline(-1.25*10^(-3),'k')
% figure()
% surf(X2000,Y2000,Z2000)
%%%%%%
% hold all
% X0=load('XisinglecompletedX0.txt');
% Y0=load('XisinglecompletedY0.txt');
% Z0=load('XisinglecompletedZ0.txt');
% X400=load('XisinglecompletedX400.txt');
% Y400=load('XisinglecompletedY400.txt');
% Z400=load('XisinglecompletedZ400.txt');
% X800=load('XisinglecompletedX800.txt');
% Y800=load('XisinglecompletedY800.txt');
% Z800=load('XisinglecompletedZ800.txt');
% X1200=load('XisinglecompletedX1200.txt');
% Y1200=load('XisinglecompletedY1200.txt');
% Z1200=load('XisinglecompletedZ1200.txt');
% X1600=load('XisinglecompletedX1600.txt');
% Y1600=load('XisinglecompletedY1600.txt');
% Z1600=load('XisinglecompletedZ1600.txt');
% X2000=load('XisinglecompletedX2000.txt');
% Y2000=load('XisinglecompletedY2000.txt');
% Z2000=load('XisinglecompletedZ2000.txt');
% plot(X0(1,:),  Y0(1,:),  '--b')
% plot(X0(17,:), Y0(17,:), '--b')
% plot(X0(:,1),  Y0(:,1),  '--b')
% plot(X0(:,17), Y0(:,17), '--b')
% plot(X400(1,:),  Y400(1,:),  '--m')
% plot(X400(17,:), Y400(17,:), '--m')
% plot(X400(:,1),  Y400(:,1),  '--m')
% plot(X400(:,17), Y400(:,17), '--m')
% plot(X800(1,:),  Y800(1,:),  '--k')
% plot(X800(17,:), Y800(17,:), '--k')
% plot(X800(:,1),  Y800(:,1),  '--k')
% plot(X800(:,17), Y800(:,17), '--k')
% plot(X1200(1,:),  Y1200(1,:),  '--r')
% plot(X1200(17,:), Y1200(17,:), '--r')
% plot(X1200(:,1),  Y1200(:,1),  '--r')
% plot(X1200(:,17), Y1200(:,17), '--r')
% plot(X1600(1,:),  Y1600(1,:),  '--g')
% plot(X1600(17,:), Y1600(17,:), '--g')
% plot(X1600(:,1),  Y1600(:,1),  '--g')
% plot(X1600(:,17), Y1600(:,17), '--g')
% plot(X2000(1,:),  Y2000(1,:),  '--c')
% plot(X2000(17,:), Y2000(17,:), '--c')
% plot(X2000(:,1),  Y2000(:,1),  '--c')
% plot(X2000(:,17), Y2000(:,17), '--c')
% yline(0.5*10^(-3),'k')
% yline(-0.5*10^(-3),'k')
% figure()
% surf(X2000,Y2000,Z2000)
%%%
% hold all
% X0=load('Xisinglecompleted25X0.txt');
% Y0=load('Xisinglecompleted25Y0.txt');
% Z0=load('Xisinglecompleted25Z0.txt');
% X400=load('Xisinglecompleted25X400.txt');
% Y400=load('Xisinglecompleted25Y400.txt');
% Z400=load('Xisinglecompleted25Z400.txt');
% X800=load('Xisinglecompleted25X800.txt');
% Y800=load('Xisinglecompleted25Y800.txt');
% Z800=load('Xisinglecompleted25Z800.txt');
% X1200=load('Xisinglecompleted25X1200.txt');
% Y1200=load('Xisinglecompleted25Y1200.txt');
% Z1200=load('Xisinglecompleted25Z1200.txt');
% X1600=load('Xisinglecompleted25X1600.txt');
% Y1600=load('Xisinglecompleted25Y1600.txt');
% Z1600=load('Xisinglecompleted25Z1600.txt');
% X2000=load('Xisinglecompleted25X2000.txt');
% Y2000=load('Xisinglecompleted25Y2000.txt');
% Z2000=load('Xisinglecompleted25Z2000.txt');
% plot(X0(1,:),  Y0(1,:),  '--b')
% plot(X0(25,:), Y0(25,:), '--b')
% plot(X0(:,1),  Y0(:,1),  '--b')
% plot(X0(:,25), Y0(:,25), '--b')
% plot(X400(1,:),  Y400(1,:),  '--m')
% plot(X400(25,:), Y400(25,:), '--m')
% plot(X400(:,1),  Y400(:,1),  '--m')
% plot(X400(:,25), Y400(:,25), '--m')
% plot(X800(1,:),  Y800(1,:),  '--k')
% plot(X800(25,:), Y800(25,:), '--k')
% plot(X800(:,1),  Y800(:,1),  '--k')
% plot(X800(:,25), Y800(:,25), '--k')
% plot(X1200(1,:),  Y1200(1,:),  '--r')
% plot(X1200(25,:), Y1200(25,:), '--r')
% plot(X1200(:,1),  Y1200(:,1),  '--r')
% plot(X1200(:,25), Y1200(:,25), '--r')
% plot(X1600(1,:),  Y1600(1,:),  '--g')
% plot(X1600(25,:), Y1600(25,:), '--g')
% plot(X1600(:,1),  Y1600(:,1),  '--g')
% plot(X1600(:,25), Y1600(:,25), '--g')
% plot(X2000(1,:),  Y2000(1,:),  '--c')
% plot(X2000(25,:), Y2000(25,:), '--c')
% plot(X2000(:,1),  Y2000(:,1),  '--c')
% plot(X2000(:,25), Y2000(:,25), '--c')
% yline(0.5*10^(-3),'k')
% yline(-0.5*10^(-3),'k')
% figure()
% surf(X2000,Y2000,Z2000)
%%%
% EXACTLY THE SAME AS XITWO
% hold all
% X0=load('XimultismallX0.txt');
% Y0=load('XimultismallY0.txt');
% Z0=load('XimultismallZ0.txt');
% X400=load('XimultismallX400.txt');
% Y400=load('XimultismallY400.txt');
% Z400=load('XimultismallZ400.txt');
% X800=load('XimultismallX800.txt');
% Y800=load('XimultismallY800.txt');
% Z800=load('XimultismallZ800.txt');
% X1200=load('XimultismallX1200.txt');
% Y1200=load('XimultismallY1200.txt');
% Z1200=load('XimultismallZ1200.txt');
% X1600=load('XimultismallX1600.txt');
% Y1600=load('XimultismallY1600.txt');
% Z1600=load('XimultismallZ1600.txt');
% X2000=load('XimultismallX2000.txt');
% Y2000=load('XimultismallY2000.txt');
% Z2000=load('XimultismallZ2000.txt');
% plot(X0(1,:),  Y0(1,:),  '--b')
% plot(X0(17,:), Y0(17,:), '--b')
% plot(X0(:,1),  Y0(:,1),  '--b')
% plot(X0(:,17), Y0(:,17), '--b')
% plot(X400(1,:),  Y400(1,:),  '--m')
% plot(X400(17,:), Y400(17,:), '--m')
% plot(X400(:,1),  Y400(:,1),  '--m')
% plot(X400(:,17), Y400(:,17), '--m')
% plot(X800(1,:),  Y800(1,:),  '--k')
% plot(X800(17,:), Y800(17,:), '--k')
% plot(X800(:,1),  Y800(:,1),  '--k')
% plot(X800(:,17), Y800(:,17), '--k')
% plot(X1200(1,:),  Y1200(1,:),  '--r')
% plot(X1200(17,:), Y1200(17,:), '--r')
% plot(X1200(:,1),  Y1200(:,1),  '--r')
% plot(X1200(:,17), Y1200(:,17), '--r')
% plot(X1600(1,:),  Y1600(1,:),  '--g')
% plot(X1600(17,:), Y1600(17,:), '--g')
% plot(X1600(:,1),  Y1600(:,1),  '--g')
% plot(X1600(:,17), Y1600(:,17), '--g')
% plot(X2000(1,:),  Y2000(1,:),  '--c')
% plot(X2000(17,:), Y2000(17,:), '--c')
% plot(X2000(:,1),  Y2000(:,1),  '--c')
% plot(X2000(:,17), Y2000(:,17), '--c')
%%%
% hold all
% X0=load('XimultimanyX0.txt');
% Y0=load('XimultimanyY0.txt');
% Z0=load('XimultimanyZ0.txt');
% X400=load('XimultimanyX400.txt');
% Y400=load('XimultimanyY400.txt');
% Z400=load('XimultimanyZ400.txt');
% X800=load('XimultimanyX800.txt');
% Y800=load('XimultimanyY800.txt');
% Z800=load('XimultimanyZ800.txt');
% X1200=load('XimultimanyX1200.txt');
% Y1200=load('XimultimanyY1200.txt');
% Z1200=load('XimultimanyZ1200.txt');
% X1600=load('XimultimanyX1600.txt');
% Y1600=load('XimultimanyY1600.txt');
% Z1600=load('XimultimanyZ1600.txt');
% X2000=load('XimultimanyX2000.txt');
% Y2000=load('XimultimanyY2000.txt');
% Z2000=load('XimultimanyZ2000.txt');
% plot(X0(1,:),  Y0(1,:),  '--b')
% plot(X0(17,:), Y0(17,:), '--b')
% plot(X0(:,1),  Y0(:,1),  '--b')
% plot(X0(:,17), Y0(:,17), '--b')
% plot(X400(1,:),  Y400(1,:),  '--m')
% plot(X400(17,:), Y400(17,:), '--m')
% plot(X400(:,1),  Y400(:,1),  '--m')
% plot(X400(:,17), Y400(:,17), '--m')
% plot(X800(1,:),  Y800(1,:),  '--k')
% plot(X800(17,:), Y800(17,:), '--k')
% plot(X800(:,1),  Y800(:,1),  '--k')
% plot(X800(:,17), Y800(:,17), '--k')
% plot(X1200(1,:),  Y1200(1,:),  '--r')
% plot(X1200(17,:), Y1200(17,:), '--r')
% plot(X1200(:,1),  Y1200(:,1),  '--r')
% plot(X1200(:,17), Y1200(:,17), '--r')
% plot(X1600(1,:),  Y1600(1,:),  '--g')
% plot(X1600(17,:), Y1600(17,:), '--g')
% plot(X1600(:,1),  Y1600(:,1),  '--g')
% plot(X1600(:,17), Y1600(:,17), '--g')
% plot(X2000(1,:),  Y2000(1,:),  '--c')
% plot(X2000(17,:), Y2000(17,:), '--c')
% plot(X2000(:,1),  Y2000(:,1),  '--c')
% plot(X2000(:,17), Y2000(:,17), '--c')
% yline(0.25*10^(-3),'k')
% yline(-0.25*10^(-3),'k')
% yline(0.75*10^(-3),'k')
% yline(-0.75*10^(-3),'k')
% yline(1.25*10^(-3),'k')
% yline(-1.25*10^(-3),'k')
% yline(1.75*10^(-3),'k')
% yline(-1.75*10^(-3),'k')
% figure()
% surf(X2000,Y2000,Z2000)
%%%
% hold all
% X0=load('Ximultimany25X0.txt');
% Y0=load('Ximultimany25Y0.txt');
% Z0=load('Ximultimany25Z0.txt');
% X400=load('Ximultimany25X400.txt');
% Y400=load('Ximultimany25Y400.txt');
% Z400=load('Ximultimany25Z400.txt');
% X800=load('Ximultimany25X800.txt');
% Y800=load('Ximultimany25Y800.txt');
% Z800=load('Ximultimany25Z800.txt');
% X1200=load('Ximultimany25X1200.txt');
% Y1200=load('Ximultimany25Y1200.txt');
% Z1200=load('Ximultimany25Z1200.txt');
% X1600=load('Ximultimany25X1600.txt');
% Y1600=load('Ximultimany25Y1600.txt');
% Z1600=load('Ximultimany25Z1600.txt');
% X2000=load('Ximultimany25X2000.txt');
% Y2000=load('Ximultimany25Y2000.txt');
% Z2000=load('Ximultimany25Z2000.txt');
% plot(X0(1,:),  Y0(1,:),  '--b')
% plot(X0(25,:), Y0(25,:), '--b')
% plot(X0(:,1),  Y0(:,1),  '--b')
% plot(X0(:,25), Y0(:,25), '--b')
% plot(X400(1,:),  Y400(1,:),  '--m')
% plot(X400(25,:), Y400(25,:), '--m')
% plot(X400(:,1),  Y400(:,1),  '--m')
% plot(X400(:,25), Y400(:,25), '--m')
% plot(X800(1,:),  Y800(1,:),  '--k')
% plot(X800(25,:), Y800(25,:), '--k')
% plot(X800(:,1),  Y800(:,1),  '--k')
% plot(X800(:,25), Y800(:,25), '--k')
% plot(X1200(1,:),  Y1200(1,:),  '--r')
% plot(X1200(25,:), Y1200(25,:), '--r')
% plot(X1200(:,1),  Y1200(:,1),  '--r')
% plot(X1200(:,25), Y1200(:,25), '--r')
% plot(X1600(1,:),  Y1600(1,:),  '--g')
% plot(X1600(25,:), Y1600(25,:), '--g')
% plot(X1600(:,1),  Y1600(:,1),  '--g')
% plot(X1600(:,25), Y1600(:,25), '--g')
% plot(X2000(1,:),  Y2000(1,:),  '--c')
% plot(X2000(25,:), Y2000(25,:), '--c')
% plot(X2000(:,1),  Y2000(:,1),  '--c')
% plot(X2000(:,25), Y2000(:,25), '--c')
% yline(0.25*10^(-3),'k')
% yline(-0.25*10^(-3),'k')
% yline(0.75*10^(-3),'k')
% yline(-0.75*10^(-3),'k')
% yline(1.25*10^(-3),'k')
% yline(-1.25*10^(-3),'k')
% yline(1.75*10^(-3),'k')
% yline(-1.75*10^(-3),'k')
% figure()
% surf(X2000,Y2000,Z2000)
%%%
% hold all
% X0=load('XimultiexactX0.txt');
% Y0=load('XimultiexactY0.txt');
% Z0=load('XimultiexactZ0.txt');
% X400=load('XimultiexactX400.txt');
% Y400=load('XimultiexactY400.txt');
% Z400=load('XimultiexactZ400.txt');
% X800=load('XimultiexactX800.txt');
% Y800=load('XimultiexactY800.txt');
% Z800=load('XimultiexactZ800.txt');
% X1200=load('XimultiexactX1200.txt');
% Y1200=load('XimultiexactY1200.txt');
% Z1200=load('XimultiexactZ1200.txt');
% X1600=load('XimultiexactX1600.txt');
% Y1600=load('XimultiexactY1600.txt');
% Z1600=load('XimultiexactZ1600.txt');
% X2000=load('XimultiexactX2000.txt');
% Y2000=load('XimultiexactY2000.txt');
% Z2000=load('XimultiexactZ2000.txt');
% plot(X0(1,:),  Y0(1,:),  '--b')
% plot(X0(25,:), Y0(25,:), '--b')
% plot(X0(:,1),  Y0(:,1),  '--b')
% plot(X0(:,25), Y0(:,25), '--b')
% plot(X400(1,:),  Y400(1,:),  '--m')
% plot(X400(25,:), Y400(25,:), '--m')
% plot(X400(:,1),  Y400(:,1),  '--m')
% plot(X400(:,25), Y400(:,25), '--m')
% plot(X800(1,:),  Y800(1,:),  '--k')
% plot(X800(25,:), Y800(25,:), '--k')
% plot(X800(:,1),  Y800(:,1),  '--k')
% plot(X800(:,25), Y800(:,25), '--k')
% plot(X1200(1,:),  Y1200(1,:),  '--r')
% plot(X1200(25,:), Y1200(25,:), '--r')
% plot(X1200(:,1),  Y1200(:,1),  '--r')
% plot(X1200(:,25), Y1200(:,25), '--r')
% plot(X1600(1,:),  Y1600(1,:),  '--g')
% plot(X1600(25,:), Y1600(25,:), '--g')
% plot(X1600(:,1),  Y1600(:,1),  '--g')
% plot(X1600(:,25), Y1600(:,25), '--g')
% plot(X2000(1,:),  Y2000(1,:),  '--c')
% plot(X2000(25,:), Y2000(25,:), '--c')
% plot(X2000(:,1),  Y2000(:,1),  '--c')
% plot(X2000(:,25), Y2000(:,25), '--c')
% yline(0.2*10^(-3),'k')
% yline(-0.2*10^(-3),'k')
% yline(0.4*10^(-3),'k')
% yline(-0.4*10^(-3),'k')
% yline(0.6*10^(-3),'k')
% yline(-0.6*10^(-3),'k')
% yline(0.8*10^(-3),'k')
% yline(-0.8*10^(-3),'k')
% yline(1.0*10^(-3),'k')
% yline(-1.0*10^(-3),'k')
% yline(1.2*10^(-3),'k')
% yline(-1.2*10^(-3),'k')
% yline(1.4*10^(-3),'k')
% yline(-1.4*10^(-3),'k')
% yline(1.6*10^(-3),'k')
% yline(-1.6*10^(-3),'k')
% yline(1.8*10^(-3),'k')
% yline(-1.8*10^(-3),'k')
% figure()
% surf(X2000,Y2000,Z2000)
% figure()
% %%
% hold all
% X0=load('Ximultiexact31X0.txt');
% Y0=load('Ximultiexact31Y0.txt');
% Z0=load('Ximultiexact31Z0.txt');
% X400=load('Ximultiexact31X400.txt');
% Y400=load('Ximultiexact31Y400.txt');
% Z400=load('Ximultiexact31Z400.txt');
% X800=load('Ximultiexact31X800.txt');
% Y800=load('Ximultiexact31Y800.txt');
% Z800=load('Ximultiexact31Z800.txt');
% X1200=load('Ximultiexact31X1200.txt');
% Y1200=load('Ximultiexact31Y1200.txt');
% Z1200=load('Ximultiexact31Z1200.txt');
% X1600=load('Ximultiexact31X1600.txt');
% Y1600=load('Ximultiexact31Y1600.txt');
% Z1600=load('Ximultiexact31Z1600.txt');
% X2000=load('Ximultiexact31X2000.txt');
% Y2000=load('Ximultiexact31Y2000.txt');
% Z2000=load('Ximultiexact31Z2000.txt');
% plot(X0(1,:),  Y0(1,:),  '--b')
% plot(X0(31,:), Y0(31,:), '--b')
% plot(X0(:,1),  Y0(:,1),  '--b')
% plot(X0(:,31), Y0(:,31), '--b')
% plot(X400(1,:),  Y400(1,:),  '--m')
% plot(X400(31,:), Y400(31,:), '--m')
% plot(X400(:,1),  Y400(:,1),  '--m')
% plot(X400(:,31), Y400(:,31), '--m')
% plot(X800(1,:),  Y800(1,:),  '--k')
% plot(X800(31,:), Y800(31,:), '--k')
% plot(X800(:,1),  Y800(:,1),  '--k')
% plot(X800(:,31), Y800(:,31), '--k')
% plot(X1200(1,:),  Y1200(1,:),  '--r')
% plot(X1200(31,:), Y1200(31,:), '--r')
% plot(X1200(:,1),  Y1200(:,1),  '--r')
% plot(X1200(:,31), Y1200(:,31), '--r')
% plot(X1600(1,:),  Y1600(1,:),  '--g')
% plot(X1600(31,:), Y1600(31,:), '--g')
% plot(X1600(:,1),  Y1600(:,1),  '--g')
% plot(X1600(:,31), Y1600(:,31), '--g')
% plot(X2000(1,:),  Y2000(1,:),  '--c')
% plot(X2000(31,:), Y2000(31,:), '--c')
% plot(X2000(:,1),  Y2000(:,1),  '--c')
% plot(X2000(:,31), Y2000(:,31), '--c')
% yline(0.2*10^(-3),'k')
% yline(-0.2*10^(-3),'k')
% yline(0.4*10^(-3),'k')
% yline(-0.4*10^(-3),'k')
% yline(0.6*10^(-3),'k')
% yline(-0.6*10^(-3),'k')
% yline(0.8*10^(-3),'k')
% yline(-0.8*10^(-3),'k')
% yline(1.0*10^(-3),'k')
% yline(-1.0*10^(-3),'k')
% yline(1.2*10^(-3),'k')
% yline(-1.2*10^(-3),'k')
% yline(1.4*10^(-3),'k')
% yline(-1.4*10^(-3),'k')
% yline(1.6*10^(-3),'k')
% yline(-1.6*10^(-3),'k')
% yline(1.8*10^(-3),'k')
% yline(-1.8*10^(-3),'k')
% figure()
% surf(X2000,Y2000,Z2000)
%%%
% hold all
% X0=load('Ximultiexact31longX0.txt');
% Y0=load('Ximultiexact31longY0.txt');
% Z0=load('Ximultiexact31longZ0.txt');
% X1000=load('Ximultiexact31longX1000.txt');
% Y1000=load('Ximultiexact31longY1000.txt');
% Z1000=load('Ximultiexact31longZ1000.txt');
% X2000=load('Ximultiexact31longX2000.txt');
% Y2000=load('Ximultiexact31longY2000.txt');
% Z2000=load('Ximultiexact31longZ2000.txt');
% X3000=load('Ximultiexact31longX3000.txt');
% Y3000=load('Ximultiexact31longY3000.txt');
% Z3000=load('Ximultiexact31longZ3000.txt');
% X4000=load('Ximultiexact31longX4000.txt');
% Y4000=load('Ximultiexact31longY4000.txt');
% Z4000=load('Ximultiexact31longZ4000.txt');
% X5000=load('Ximultiexact31longX5000.txt');
% Y5000=load('Ximultiexact31longY5000.txt');
% Z5000=load('Ximultiexact31longZ5000.txt');
% plot(X0(1,:),  Y0(1,:),  '--b')
% plot(X0(31,:), Y0(31,:), '--b')
% plot(X0(:,1),  Y0(:,1),  '--b')
% plot(X0(:,31), Y0(:,31), '--b')
% plot(X1000(1,:),  Y1000(1,:),  '--m')
% plot(X1000(31,:), Y1000(31,:), '--m')
% plot(X1000(:,1),  Y1000(:,1),  '--m')
% plot(X1000(:,31), Y1000(:,31), '--m')
% plot(X2000(1,:),  Y2000(1,:),  '--k')
% plot(X2000(31,:), Y2000(31,:), '--k')
% plot(X2000(:,1),  Y2000(:,1),  '--k')
% plot(X2000(:,31), Y2000(:,31), '--k')
% plot(X3000(1,:),  Y3000(1,:),  '--r')
% plot(X3000(31,:), Y3000(31,:), '--r')
% plot(X3000(:,1),  Y3000(:,1),  '--r')
% plot(X3000(:,31), Y3000(:,31), '--r')
% plot(X4000(1,:),  Y4000(1,:),  '--g')
% plot(X4000(31,:), Y4000(31,:), '--g')
% plot(X4000(:,1),  Y4000(:,1),  '--g')
% plot(X4000(:,31), Y4000(:,31), '--g')
% plot(X5000(1,:),  Y5000(1,:),  '--c')
% plot(X5000(31,:), Y5000(31,:), '--c')
% plot(X5000(:,1),  Y5000(:,1),  '--c')
% plot(X5000(:,31), Y5000(:,31), '--c')
% yline(0.2*10^(-3),'k')
% yline(-0.2*10^(-3),'k')
% yline(0.4*10^(-3),'k')
% yline(-0.4*10^(-3),'k')
% yline(0.6*10^(-3),'k')
% yline(-0.6*10^(-3),'k')
% yline(0.8*10^(-3),'k')
% yline(-0.8*10^(-3),'k')
% yline(1.0*10^(-3),'k')
% yline(-1.0*10^(-3),'k')
% yline(1.2*10^(-3),'k')
% yline(-1.2*10^(-3),'k')
% yline(1.4*10^(-3),'k')
% yline(-1.4*10^(-3),'k')
% yline(1.6*10^(-3),'k')
% yline(-1.6*10^(-3),'k')
% yline(1.8*10^(-3),'k')
% yline(-1.8*10^(-3),'k')
% figure()
% surf(X5000,Y5000,Z5000)