X1100=load('furtherpart2X1100.txt');
Y1100=load('furtherpart2Y1100.txt');
Z1100=load('furtherpart2Z1100.txt');
% figure('Name', '1100');
surf(X1100,Y1100,Z1100);
figure();
plot(X1100,Y1100);
% hold all;
% figure;
hold on
% plot(x,negy)
% plot(X0(1,:), Y0(1,:), '--b')
% plot(X0(17, :), Y0(17,:), '--b')
% plot(X0(:,1), Y0(:,1), '--b')
% plot(X0(:,17), Y0(:,17), '-b')
% yline(.5*10^(-3),'m')
% yline(-0.5*10^(-3),'m')
% theta = zeros(17,17);
% 
% adj = sqrt( (X1100(2,2)-X1100(1,1))^2 + (Y1100(2,2)-Y1100(1,1))^2);
% opp = Z1100(2,2) - Z1100(1,1);
% theta(1,1) = atan(opp/adj)
% adj = sqrt( (X1100(2,16)-X1100(1,17))^2 + (Y1100(2,16)-Y1100(1,17))^2);
% opp = Z1100(2,16) - Z1100(1,17);
% theta(1,17) = atan(opp/adj)
% adj = sqrt( (X1100(16,2)-X1100(17,1))^2 + (Y1100(16,2)-Y1100(17,1))^2);
% opp = Z1100(16,2) - Z1100(17,1);
% theta(17,1) = atan(opp/adj)
% adj = sqrt( (X1100(16,16)-X1100(17,17))^2 + (Y1100(16,16)-Y1100(17,17))^2);
% opp = Z1100(16,16) - Z1100(17,17);
% theta(17,17) = atan(opp/adj)
% for i=2:16
%     adj = sqrt( (X1100(2,i)-X1100(1,i))^2 + (Y1100(2,i)-Y1100(1,i))^2);
% 	opp = Z1100(2,i) - Z1100(1,i);
%     theta(1,i) = atan(opp/adj);
%     adj = sqrt( (X1100(i,2)-X1100(i,1))^2 + (Y1100(i,2)-Y1100(i,1))^2);
% 	opp = Z1100(i,2) - Z1100(i,1);
%     theta(i,1) = atan(opp/adj);
%     adj = sqrt( (X1100(16,i)-X1100(17,i))^2 + (Y1100(16,i)-Y1100(17,i))^2);
% 	opp = Z1100(16,i) - Z1100(17,i);
%     theta(17,i) = atan(opp/adj);
%     adj = sqrt( (X1100(i,16)-X1100(i,17))^2 + (Y1100(i,16)-Y1100(i,17))^2);
% 	opp = Z1100(i,16) - Z1100(i,17);
%     theta(i,17) = atan(opp/adj);
% end
% theta;